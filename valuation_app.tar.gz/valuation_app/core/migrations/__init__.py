"""Core app migrations."""
